print("Shona: Mhoroyi vhanu vese")
print("Ndebele: Sabona mhlaba")